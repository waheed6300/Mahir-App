package com.example.note_a;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDB extends SQLiteOpenHelper {

    public static final String DB_NAME = "Note.db";
    public static final String TABLE_Name = "Note_Info";
    //public static final String ID = "ID";
    public static final String NAME = "Name";
    public static final String MAIL = "Mail";
    public static final String PASSWORD = "Password";
    //public static final String MESSAGE = "Message";

    public MyDB(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(String.format("CREATE TABLE " + TABLE_Name + "(Name TEXT, Mail TEXT PRIMARY KEY, Password TEXT)"));
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(String.format("DROP TABLE IF EXISTS%s", TABLE_Name));
        onCreate(db);
    }

    public boolean insert(String name, String mail, String pass){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME, name);
        contentValues.put(MAIL, mail);
        contentValues.put(PASSWORD, pass);
        long result = db.insert(TABLE_Name, null, contentValues);
        if (result == -1){
            return false;
        }else {
            return true;
        }
    }

    public boolean checkMail(String mail){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from "+TABLE_Name+" where Mail =?", new String[]{mail});
        if (cursor.getCount()>0){
            return true;
        }else {
            return false;
        }
    }

    public boolean validateUser(String mail, String pass){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from "+TABLE_Name+" where Mail =? and Password=?", new String[]{mail, pass});
        if (cursor.getCount()>0){
            return true;
        }else {
            return false;
        }
    }
}
