package com.example.note_a;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationForm extends AppCompatActivity implements View.OnClickListener{

    MyDB Database;
    EditText name, mail, pass;
    Button btnRegister;
    String user_Name, user_mail, user_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);

        Database = new MyDB(this);
        name = (EditText)findViewById(R.id.txtName);
        mail = (EditText)findViewById(R.id.txtEmail);
        pass = (EditText)findViewById(R.id.txtPass_reg);

        btnRegister = (Button)findViewById(R.id.btnSignUp);
        btnRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        user_Name=name.getText().toString();
        user_mail=mail.getText().toString();
        user_password=pass.getText().toString();
        switch (v.getId()){
            case R.id.btnSignUp:
                //Toast.makeText(this, "Name: "+User_Name+"Mail: "+user_mail+"Password: "+user_password, Toast.LENGTH_LONG).show();
                if (name.getText().length()==0){
                    name.setError("Please fill this field...!!");
                } else if (mail.getText().length()==0){
                    mail.setError("Please fill this field...!!");
                }else if (pass.getText().length()==0){
                    pass.setError("Please fill this field...!!");
                }else {
                    boolean validateUser = Database.checkMail(user_mail);
                    if (validateUser == true){
                        mail.setError("Username already exist...!!");
                    }else {
                        boolean isSent = Database.insert(user_Name,user_mail, user_password);
                        if (isSent == true){
                            Toast.makeText(this, "Registration Success...!!", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(this, loginForm.class));
                            this.finish();
                        }else {
                            Toast.makeText(this, "Registration not Success...!!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
                break;
        }
    }
}
